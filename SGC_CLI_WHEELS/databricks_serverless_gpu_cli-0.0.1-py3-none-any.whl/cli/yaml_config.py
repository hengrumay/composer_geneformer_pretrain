"""YAML configuration schema and validation using Pydantic.

This module defines the complete schema for training YAML configuration files,
including validation rules for all fields and nested structures.
"""

from pydantic import BaseModel, Field, field_validator, model_validator, ConfigDict
from typing import Optional, Dict, Any

from cli.compute import GPUType, get_gpus_per_node


class WorkspaceConfig(BaseModel):
    """Workspace configuration for specifying Databricks workspace."""

    model_config = ConfigDict(extra="forbid")

    host: Optional[str] = None

    @field_validator("host")
    @classmethod
    def validate_host(cls, v: Optional[str]) -> Optional[str]:
        """Validate workspace host is not empty if provided."""
        if v is not None:
            v = v.strip()
            if not v:
                raise ValueError("workspace.host cannot be empty")
        return v


class DockerImageConfig(BaseModel):
    """Docker image configuration for custom containers."""

    model_config = ConfigDict(extra="forbid")

    url: str = Field(description="Docker image URL in format 'organization/repository:tag'")

    @field_validator("url")
    @classmethod
    def validate_url(cls, v: str) -> str:
        """Validate docker image URL is not empty."""
        v = v.strip()
        if not v:
            raise ValueError("docker_image.url cannot be empty")
        return v


class EnvironmentConfig(BaseModel):
    """Environment configuration for dependencies and variables."""

    model_config = ConfigDict(extra="forbid")

    dependencies: Optional[str] = None
    env_variables: Optional[Dict[str, str]] = None
    env_variables_secrets: Optional[Dict[str, str]] = None
    docker_image: Optional[DockerImageConfig] = None

    @field_validator("env_variables_secrets")
    @classmethod
    def validate_secrets(cls, v: Optional[Dict[str, str]]) -> Optional[Dict[str, str]]:
        """Validate secret references are in 'scope/key' format."""
        if v is not None:
            for var_name, secret_ref in v.items():
                if "/" not in secret_ref or len(secret_ref.split("/")) != 2:
                    raise ValueError(
                        f"Invalid secret reference '{secret_ref}' for variable '{var_name}'. "
                        f"Expected format 'scope/key' (e.g., my_scope/hf_token)"
                    )
                parts = secret_ref.split("/")
                if not parts[0] or not parts[1]:
                    raise ValueError(
                        f"Invalid secret reference '{secret_ref}' for variable '{var_name}'. "
                        f"Scope and key cannot be empty"
                    )
        return v

    @model_validator(mode="after")
    def handle_docker_image(self) -> "EnvironmentConfig":
        """Validate that docker_image cannot coexist with other environment fields."""
        # Check docker_image conflicts with other fields
        if self.docker_image is not None:
            conflicting_fields = []
            if self.dependencies is not None:
                conflicting_fields.append("dependencies")
            if self.env_variables is not None:
                conflicting_fields.append("env_variables")
            if self.env_variables_secrets is not None:
                conflicting_fields.append("env_variables_secrets")

            if conflicting_fields:
                fields_str = ", ".join(conflicting_fields)
                raise ValueError(
                    f"When 'docker_image' is specified under 'environment', "
                    f"the following fields are not allowed: {fields_str}. "
                    f"Please remove these fields or remove 'docker_image'."
                )
        return self


class ComputeConfig(BaseModel):
    """Compute configuration for GPU resources."""

    model_config = ConfigDict(extra="forbid")

    gpus: int = Field(gt=0, description="Number of GPUs (must be positive)")
    gpu_type: str = Field(description="Type of GPU (e.g., 'h100_80gb', 'a10')")
    gpu_node_pool_id: Optional[str] = None
    gpu_pool_name: Optional[str] = None

    @field_validator("gpu_type")
    @classmethod
    def validate_gpu_type(cls, v: str) -> str:
        """Validate GPU type is recognized."""
        try:
            GPUType(v)
        except (ValueError, KeyError):
            valid_types = ", ".join([f"'{t.value}'" for t in GPUType])
            raise ValueError(f"Invalid gpu_type '{v}'. Must be one of: {valid_types}")
        return v

    @model_validator(mode="after")
    def validate_gpu_count(self) -> "ComputeConfig":
        """Validate GPU count matches hardware topology (multiples of GPUs per node)."""
        gpu_type_enum = GPUType(self.gpu_type)
        gpus_per_node = get_gpus_per_node(gpu_type_enum)

        if self.gpus % gpus_per_node != 0:
            raise ValueError(
                f"Invalid GPU count for {self.gpu_type}: {self.gpus}. "
                f"{self.gpu_type} requires multiples of {gpus_per_node} GPUs. "
            )
        return self

    @model_validator(mode="after")
    def validate_pool_fields(self) -> "ComputeConfig":
        """Validate that only one of gpu_node_pool_id or gpu_pool_name is specified."""
        if self.gpu_node_pool_id and self.gpu_pool_name:
            raise ValueError("Cannot specify both 'gpu_node_pool_id' and 'gpu_pool_name'. " "Please use only one.")
        return self


class RepoSnapshotConfig(BaseModel):
    """Repository snapshot configuration for code tarballs."""

    model_config = ConfigDict(extra="forbid")

    local_repo_path: Optional[str] = None
    remote_volume: Optional[str] = None
    git_commit: Optional[str] = None
    git_branch: Optional[str] = None

    @field_validator("remote_volume")
    @classmethod
    def validate_volume(cls, v: Optional[str]) -> Optional[str]:
        """Validate volume path starts with /Volumes/."""
        if v is not None and not v.startswith("/Volumes/"):
            raise ValueError(
                "repo_snapshot.remote_volume must start with '/Volumes/' "
                "(e.g., '/Volumes/catalog/schema/volume/path')"
            )
        return v


class YamlConfig(BaseModel):
    """Complete YAML configuration schema for training runs."""

    model_config = ConfigDict(extra="forbid")

    # Required fields
    experiment_name: str
    environment: EnvironmentConfig
    compute: ComputeConfig

    # Script fields
    python_script: Optional[str] = None
    bash_script: Optional[str] = None

    # Optional fields
    workspace: Optional[WorkspaceConfig] = None
    git_repo: Optional[str] = None
    git_branch: Optional[str] = None
    git_secret: Optional[str] = None
    repo_snapshot: Optional[RepoSnapshotConfig] = None
    max_retries: int = Field(default=0, ge=0)
    timeout_minutes: Optional[int] = Field(default=None, ge=1)
    idempotency_token: Optional[str] = None
    parameters: Optional[Dict[str, Any]] = Field(default=None)
    run_name: Optional[str] = None

    @field_validator("git_secret")
    @classmethod
    def validate_git_secret(cls, v: Optional[str]) -> Optional[str]:
        """Validate git secret reference format."""
        if v is not None:
            parts = v.split("/")
            if len(parts) != 2 or not parts[0] or not parts[1]:
                raise ValueError(
                    f"Invalid git_secret format '{v}'. " f"Expected format 'scope/key' (e.g., my_scope/git_token)"
                )
        return v

    @field_validator("idempotency_token")
    @classmethod
    def validate_idempotency_token(cls, v: Optional[str]) -> Optional[str]:
        """Validate idempotency token is not empty and within length limits."""
        if v is not None:
            v = v.strip()
            if not v:
                raise ValueError("idempotency_token cannot be empty")
            if len(v) > 64:
                raise ValueError("idempotency_token must be 64 characters or less")
        return v

    @field_validator("run_name")
    @classmethod
    def validate_mlflow_run_name(cls, v: Optional[str]) -> Optional[str]:
        """Validate MLflow run name is not empty if provided."""
        if v is not None:
            v = v.strip()
            if not v:
                raise ValueError("run_name cannot be empty")
        return v

    @model_validator(mode="after")
    def validate_script_fields(self) -> "YamlConfig":
        """Ensure exactly one script field is provided."""
        if self.python_script and self.bash_script:
            raise ValueError("Cannot specify both 'python_script' and 'bash_script'. Choose one.")
        if not self.python_script and not self.bash_script:
            raise ValueError("Must specify either 'python_script' or 'bash_script'")
        return self
