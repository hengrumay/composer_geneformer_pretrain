"""Log streaming utilities for CLI workload monitoring.

This module provides log streaming capabilities for monitoring
serverless GPU workloads via the CLI, adapted from Skyrun's log streaming.
"""

import collections
import contextlib
import logging
import os
import shutil
import tempfile
import time
from typing import Dict, Optional, Tuple, List
from concurrent.futures import ThreadPoolExecutor, as_completed
import sys

import mlflow
from rich.console import Console
from rich.spinner import Spinner
from rich.live import Live
from rich.panel import Panel
from rich.text import Text

from cli.jobs_api_client import JobsApiClient

log = logging.getLogger(__name__)
logging.getLogger("databricks.sdk").setLevel(logging.WARNING)

RETRY_CHECK_INTERVAL_SECONDS: int = 5
RETRY_CHECK_INTERVAL_ITERATIONS = int(RETRY_CHECK_INTERVAL_SECONDS / 0.5)


# TODO: These should be imported and centralized with Skyrun.
# Terminal states where job monitoring should stop
TERMINAL_STATES = {"TERMINATED", "SKIPPED", "INTERNAL_ERROR"}
TERMINAL_RESULT_STATES = {"SUCCESS", "FAILED", "CANCELED"}


# TODO: break this out into a common utils module
def configure_mlflow_for_current_profile() -> None:
    profile = os.getenv("DATABRICKS_CONFIG_PROFILE")
    if profile:
        # Use that profile from ~/.databrickscfg
        tracking_uri = f"databricks://{profile}"
    else:
        # Fall back to DEFAULT profile
        tracking_uri = "databricks"

    mlflow.set_tracking_uri(tracking_uri)


@contextlib.contextmanager
def _patch_env(**environs: str):
    """Context manager that patches os.environ with environs.

    The original os.environ values are restored at the end.

    Args:
        **environs: Environment variables to set temporarily
    """
    # Capture the original environ values
    original_environs = {k: os.environ.get(k) for k in environs}

    # Patch the environment
    for k, v in environs.items():
        os.environ[k] = v
    try:
        yield
    finally:
        # Restore the original environ values
        for k, v in original_environs.items():
            if v is None:
                if k in os.environ:
                    del os.environ[k]
            else:
                os.environ[k] = v


def print_new_logs(run_id: str, artifact_path: str, dst_path: str, last_position: int) -> int:
    """Fetch and print new content from a log artifact in MLflow.

    Modeled after Skyrun's print_new_logs function.

    Downloads the log file artifact from MLflow and prints any new content
    since the last read position.

    Args:
        run_id: The MLflow run ID containing the artifact
        artifact_path: Path to the log file artifact within the run
        dst_path: Local directory to download artifacts to
        last_position: The last read byte position in the file

    Returns:
        int: The updated last read byte position after reading new content
    """
    try:
        # Download the artifact file, suppressing progress bars and output
        with _patch_env(MLFLOW_ENABLE_ARTIFACTS_PROGRESS_BAR="false"):
            with open(os.devnull, "w") as devnull:
                with contextlib.redirect_stdout(devnull), contextlib.redirect_stderr(devnull):
                    mlflow_client = mlflow.MlflowClient()
                    mlflow_client.download_artifacts(run_id=run_id, path=artifact_path, dst_path=dst_path)
    except Exception as e:
        log.debug(f"Failed to download artifact: {e}")
        # Silently fail if artifact not yet available
        pass

    local_file_path = os.path.join(dst_path, artifact_path)

    if not os.path.isfile(local_file_path):
        return last_position

    with open(local_file_path, "r") as file:
        # Move to the last read position
        file.seek(last_position)
        # Read any new content
        new_content = file.read()
        if new_content:
            print(new_content, end="", flush=True)
            # Update the last_position to the current file position
            last_position = file.tell()

    return last_position


def _get_mlflow_run_id_and_log_path(
    client: JobsApiClient,
    run_id: str,
    gpus_per_node: int = 8,
    rank: int = 0,
) -> tuple[str | None, str | None, str | None]:
    """Extract MLflow run ID and log path from job output.

    Args:
        client: JobsApiClient instance
        run_id: The job run ID
        rank: The global GPU rank to fetch logs from (default: 0)
        gpus_per_node: Number of GPUs per node (needed to calculate correct log path)

    Returns:
        Tuple of (mlflow_run_id, log_artifacts_path, log_file_name) or (None, None, None) if not available

        Log structure:
        - Node X, local rank 0: logs/node_X/logs-0.chunk.txt
        - Node X, local rank 1-7: logs/node_X/gpu_Y-0.chunk.txt
    """
    try:
        run_output = client.get_run_output(run_id)
        gen_ai_output = run_output.get("gen_ai_compute_output", {})
        run_info = gen_ai_output.get("run_info", {})
        mlflow_run_id = run_info.get("mlflow_run_id")

        if mlflow_run_id:
            # Calculate node and local rank
            node_id: int = rank // gpus_per_node
            local_rank: int = rank % gpus_per_node

            # Construct log path based on local rank
            log_artifacts_path: str = f"logs/node_{node_id}"
            if local_rank == 0:
                log_file_name = "logs-0.chunk.txt"
            else:
                log_file_name: str = f"gpu_{local_rank}-0.chunk.txt"

            log.debug(
                f"Found MLflow run ID: {mlflow_run_id}, "
                f"log path: {log_artifacts_path}/{log_file_name} "
                f"(global rank {rank} -> node {node_id}, local rank {local_rank})"
            )
            return mlflow_run_id, log_artifacts_path, log_file_name
    except Exception as e:
        log.debug(f"MLflow run ID not yet available: {e}")

    return None, None, None


def extract_last_n_lines(log_file_path: str, last_n_lines: int = 200) -> Optional[List[str]]:
    """Extract the last N lines of a log file.

    Args:
        log_file_path: Path to log file
        last_n_lines: Number of lines from end of file to scan (default: 500)

    Returns:
        Last N lines of the log file.
        Returns None if the log file does not exist.
    """
    if not os.path.isfile(log_file_path):
        return None

    # Read last N lines efficiently using deque
    try:
        with open(log_file_path, "r", encoding="utf-8", errors="replace") as f:
            last_lines = list(collections.deque(f, maxlen=last_n_lines))
    except Exception as e:
        log.error(f"Failed to read log file {log_file_path}: {e}")
        return None

    return last_lines


def _download_single_node_log(
    node_id: int, run_id: str, gpus_per_node: int, dst_path: str
) -> Tuple[int, Optional[str]]:
    """Helper function to download logs from a single node.

    Args:
        node_id: Node ID to download logs from
        run_id: Job run ID
        gpus_per_node: GPUs per node
        dst_path: Local directory to download logs to

    Returns:
        Tuple of (node_id, local_file_path) or (node_id, None) if download failed
    """
    client = JobsApiClient()

    try:
        # Get MLflow run ID and log path for this node (local rank 0 only)
        mlflow_run_id, log_artifacts_path, log_file_name = _get_mlflow_run_id_and_log_path(
            client,
            run_id,
            rank=node_id * gpus_per_node,
            gpus_per_node=gpus_per_node,
        )

        if not mlflow_run_id or not log_artifacts_path or not log_file_name:
            log.debug(f"No MLflow run ID found for node {node_id}, skipping")
            return (node_id, None)

        # Download the log artifact
        artifact_path = os.path.join(log_artifacts_path, log_file_name)

        try:
            with _patch_env(MLFLOW_ENABLE_ARTIFACTS_PROGRESS_BAR="false"):
                mlflow_client = mlflow.MlflowClient()
                mlflow_client.download_artifacts(run_id=mlflow_run_id, path=artifact_path, dst_path=dst_path)

            local_file_path = os.path.join(dst_path, artifact_path)

            if os.path.isfile(local_file_path):
                log.debug(f"Downloaded logs for node {node_id}")
                return (node_id, local_file_path)
            else:
                log.debug(f"Log file not found after download for node {node_id}")
                return (node_id, None)

        except Exception as e:
            log.debug(f"Failed to download logs for node {node_id}: {e}")
            return (node_id, None)

    except Exception as e:
        log.debug(f"Error processing node {node_id}: {e}")
        return (node_id, None)


def download_all_node_logs(
    run_id: str, num_nodes: int, dst_path: str, gpus_per_node: int, max_workers: int = 8
) -> Dict[int, str]:
    """Download logs from all nodes in parallel.

    Args:
        run_id: Job run ID
        num_nodes: Total number of nodes in the run
        dst_path: Local directory to download logs to
        gpus_per_node: GPUs per node
        max_workers: Maximum number of concurrent downloads

    Returns:
        Dict mapping node_id -> local_log_file_path
        Only includes nodes where logs were successfully downloaded
    """
    configure_mlflow_for_current_profile()

    log.debug(f"Downloading logs from {num_nodes} nodes (max {max_workers} concurrent)...")

    node_logs = {}

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(_download_single_node_log, node_id, run_id, gpus_per_node, dst_path): node_id
            for node_id in range(num_nodes)
        }

        for future in as_completed(futures):
            node_id, local_file_path = future.result()
            if local_file_path:
                node_logs[node_id] = local_file_path

    log.debug(f"Successfully downloaded logs from {len(node_logs)} out of {num_nodes} nodes")
    return node_logs


def _get_key() -> str:
    """Read a single keypress from stdin.

    Returns:
        str: The key pressed (e.g., 'q', '\x1b[C' for right arrow)
    """
    import sys
    import tty
    import termios

    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(sys.stdin.fileno())
        ch = sys.stdin.read(1)
        # Handle arrow keys (escape sequences)
        if ch == "\x1b":
            ch += sys.stdin.read(2)
        return ch
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)


def _display_single_node_error(
    console: Console, node_id: int, lines: List[str], current_idx: int, total_nodes: int
) -> None:
    """Display logs from a single node with navigation controls.

    Args:
        console: Rich console for output
        node_id: Node ID
        lines: Log lines to display
        current_idx: Current index in the list of nodes (0-indexed)
        total_nodes: Total number of nodes
    """

    # Clear screen
    console.clear()

    # Show navigation info at top
    nav_text = Text()
    nav_text.append(f"Node {node_id} ", style="bold yellow")
    nav_text.append(f"[{current_idx + 1}/{total_nodes}]\n", style="dim")
    nav_text.append("Navigation: ", style="bold cyan")
    nav_text.append("← Prev  ", style="cyan")
    nav_text.append("→ Next  ", style="cyan")
    nav_text.append("Q Quit\n\n", style="cyan")
    console.print(nav_text)

    # Format header
    header = f"Node {node_id} Logs"

    # Format error content
    error_text = Text()
    for line in lines:
        # Highlight lines with key error keywords
        if any(keyword in line.lower() for keyword in ["error", "failed", "timeout", "exception", "traceback"]):
            error_text.append(line.rstrip("\n") + "\n", style="bold red")
        else:
            error_text.append(line.rstrip("\n") + "\n", style="red")

    console.print(Panel(error_text, title=header, border_style="red", expand=False))

    # Show navigation info at bottom as well
    console.print()
    bottom_nav_text = Text()
    bottom_nav_text.append(f"Node {node_id} ", style="bold yellow")
    bottom_nav_text.append(f"[{current_idx + 1}/{total_nodes}]\n", style="dim")
    bottom_nav_text.append("Navigation: ", style="bold cyan")
    bottom_nav_text.append("← Prev  ", style="cyan")
    bottom_nav_text.append("→ Next  ", style="cyan")
    bottom_nav_text.append("Q Quit", style="cyan")
    console.print(bottom_nav_text)


def display_debug_logs(node_logs: Dict[int, str], last_n_lines: int = 200) -> None:
    """Display debug logs with interactive navigation.

    Shows the last N lines from each node one at a time with arrow key navigation.

    Args:
        node_logs: Dict mapping node_id -> local log file path
        last_n_lines: Number of lines from end of each log to display (default: 200)
    """

    console = Console()

    console.print(f"\n[bold cyan]Analyzing last {last_n_lines} lines from each node...[/bold cyan]\n")

    # Collect the last N lines from each node
    all_node_logs: Dict[int, Optional[List[str]]] = {}

    for node_id in sorted(node_logs.keys()):
        log_file_path = node_logs[node_id]
        lines = extract_last_n_lines(log_file_path, last_n_lines=last_n_lines)
        all_node_logs[node_id] = lines

    # Check if we can use interactive mode
    if sys.stdin.isatty() and sys.stdout.isatty():
        console.print("[dim]Starting interactive viewer... (use arrow keys to navigate)[/dim]\n")
        time.sleep(1)

        # Interactive navigation
        node_ids = sorted(all_node_logs.keys())
        current_idx = 0

        try:
            while True:
                node_id = node_ids[current_idx]
                lines = all_node_logs[node_id]

                _display_single_node_error(console, node_id, lines, current_idx, len(node_ids))

                # Get user input
                key = _get_key()

                if key == "\x1b[C":  # Right arrow
                    current_idx = (current_idx + 1) % len(node_ids)
                elif key == "\x1b[D":  # Left arrow
                    current_idx = (current_idx - 1) % len(node_ids)
                elif key in ("q", "Q"):
                    console.clear()
                    console.print("\n[dim]Exited interactive viewer[/dim]\n")
                    break

        except KeyboardInterrupt:
            console.clear()
            console.print("\n[dim]Exited interactive viewer[/dim]\n")
    else:
        # Non-interactive fallback: display all logs
        console.print("[bold cyan]Node Logs:[/bold cyan]\n")

        for node_id in sorted(all_node_logs.keys()):
            lines = all_node_logs[node_id]

            if lines is None or len(lines) == 0:
                continue

            header = f"Node {node_id} - Last {last_n_lines} lines"

            log_text = Text()
            for line in lines:
                if any(keyword in line.lower() for keyword in ["error", "failed", "timeout", "exception"]):
                    log_text.append(line.rstrip("\n") + "\n", style="bold red")
                else:
                    log_text.append(line.rstrip("\n") + "\n", style="white")

            console.print(Panel(log_text, title=header, border_style="cyan", expand=False))
            console.print()

    console.print(f"\n[dim]Note: Analysis limited to last {last_n_lines} lines per node[/dim]")


def print_all_logs(run_id: str, rank: int = 0, num_lines: int | None = None) -> bool:
    """Print all logs for a completed run.

    This function fetches and prints the complete logs from a finished job run.
    It does not poll or stream - it's designed for jobs that have already completed.

    Args:
        run_id: The job run ID to get logs from
        rank: The rank/node number to fetch logs from (default: 0)
        num_lines: Optional number of lines to print from the end (if None, prints all logs)

    Returns:
        bool: True if logs were successfully retrieved, False otherwise
    """
    client = JobsApiClient()
    tmpdir = None

    configure_mlflow_for_current_profile()

    try:
        tmpdir = tempfile.mkdtemp()

        # Get the status to verify it's a valid run
        try:
            _ = client.get_workload_status(run_id)
        except Exception as e:
            log.error(f"Failed to get job status: {e}")
            return False

        # Get compute config to determine gpus_per_node
        compute_config = client.get_compute_config(run_id)
        gpus_per_node = compute_config["gpus_per_node"]

        # Get MLflow run ID and log path
        mlflow_run_id, log_artifacts_path, log_file_name = _get_mlflow_run_id_and_log_path(
            client, run_id, rank=rank, gpus_per_node=gpus_per_node
        )

        if not mlflow_run_id or not log_artifacts_path or not log_file_name:
            log.warning(f"No logs available for run {run_id} and rank {rank} yet")
            return False

        artifact_path = os.path.join(log_artifacts_path, "logs-0.chunk.txt")

        if num_lines is not None:
            # Download logs and print only last N lines
            try:
                log.info(f"Printing the last {num_lines} lines of logs...")
                # Download the artifact file without printing
                with open(os.devnull, "w") as devnull:
                    with contextlib.redirect_stdout(devnull), contextlib.redirect_stderr(devnull):
                        mlflow_client = mlflow.MlflowClient()
                        mlflow_client.download_artifacts(run_id=mlflow_run_id, path=artifact_path, dst_path=tmpdir)

                # Read the file and print last N lines
                local_file_path = os.path.join(tmpdir, artifact_path)
                if os.path.isfile(local_file_path):
                    with open(local_file_path, "r") as file:
                        lines = file.readlines()
                        # Print last N lines
                        for line in lines[-num_lines:]:
                            print(line, end="", flush=True)
                else:
                    log.warning("Log file not found")
                    return False
            except Exception as e:
                log.error(f"Failed to download and print logs: {e}")
                return False
        else:
            # Print all logs from the beginning
            print_new_logs(
                run_id=mlflow_run_id,
                artifact_path=artifact_path,
                dst_path=tmpdir,
                last_position=0,
            )

        return True

    finally:
        if tmpdir is not None:
            shutil.rmtree(tmpdir, ignore_errors=True)


def monitor_and_stream_logs(run_id: str, rank: int = 0) -> bool:
    """Monitor job status and stream logs in real-time.

    Modeled after Skyrun's monitor_and_log_remote_execution function.

    Continuously polls the job status and streams logs to stdout once
    the job starts running. Continues until the job reaches a terminal state.

    Args:
        run_id: The job run ID to monitor
        rank: The global GPU rank to fetch logs from (default: 0)

    Returns:
        bool: True if job completed successfully, False otherwise
    """
    client = JobsApiClient()
    tmpdir: str = ""
    mlflow_run_id: str | None = None
    full_log_file_path: str | None = None
    last_position = 0
    previous_state: str | None = None
    spinner_active = False
    console = Console()
    retry_check_counter = 0
    success: bool = False
    gpus_per_node: int = 8

    configure_mlflow_for_current_profile()

    try:
        tmpdir = tempfile.mkdtemp()

        # Get compute config to determine gpus_per_node (do this once at the start)
        try:
            compute_config = client.get_compute_config(run_id)
            gpus_per_node = compute_config["gpus_per_node"]
        except Exception as e:
            log.warning(f"Failed to get compute config, assuming rank refers to node directly: {e}")
            gpus_per_node: int = 8

        # Create spinner that shows while waiting for logs to start
        spinner = Spinner("dots", text=f"Waiting for run to start (rank {rank})...")
        live = Live(spinner, console=console, refresh_per_second=10)

        while True:
            try:
                status_info = client.get_workload_status(run_id)
            except Exception as e:
                log.error(f"Failed to get job status: {e}")
                time.sleep(2)
                continue

            state = status_info.get("state", {})
            lifecycle_state = state.get("life_cycle_state", "UNKNOWN")
            result_state = state.get("result_state", "")

            # Start spinner if we haven't printed any logs yet and no terminal state
            if last_position == 0 and not spinner_active and not result_state:
                live.start()
                spinner_active = True

            # Only log state changes to avoid spam
            current_state = f"{lifecycle_state}:{result_state}" if result_state else lifecycle_state
            if current_state != previous_state:
                if result_state:
                    log.debug(f"Job status: {result_state}")
                else:
                    log.debug(f"Job status: {lifecycle_state}")
                previous_state = current_state

            # If job is running, try to get MLflow run ID and stream logs
            if lifecycle_state == "RUNNING":
                retry_check_counter += 1

                # Check for new/changed MLflow run ID periodically (every 5 seconds)
                if mlflow_run_id is None or retry_check_counter % RETRY_CHECK_INTERVAL_ITERATIONS == 0:
                    new_mlflow_run_id, new_log_artifacts_path, new_log_file_name = _get_mlflow_run_id_and_log_path(
                        client, run_id, rank=rank, gpus_per_node=gpus_per_node
                    )

                    # Detect if MLflow run ID changed (retry occurred)
                    if new_mlflow_run_id and mlflow_run_id and new_mlflow_run_id != mlflow_run_id:
                        assert new_log_artifacts_path and new_log_file_name
                        # Stop spinner if active before printing message
                        if spinner_active:
                            live.stop()
                            spinner_active = False
                        print("\n⚠️  Job retried, switching to new task run logs...\n", flush=True)
                        mlflow_run_id = new_mlflow_run_id
                        full_log_file_path = os.path.join(new_log_artifacts_path, new_log_file_name)
                        last_position = 0  # Reset to read new logs from beginning
                    elif new_mlflow_run_id and mlflow_run_id is None:
                        # First time getting MLflow run ID
                        assert new_log_artifacts_path and new_log_file_name
                        mlflow_run_id = new_mlflow_run_id
                        full_log_file_path = os.path.join(new_log_artifacts_path, new_log_file_name)

                # If we have the MLflow run ID, stream logs
                if mlflow_run_id and full_log_file_path:
                    new_position = print_new_logs(
                        run_id=mlflow_run_id,
                        artifact_path=full_log_file_path,
                        dst_path=tmpdir,
                        last_position=last_position,
                    )

                    # Stop spinner once we've actually printed logs (position changed from 0)
                    if new_position > 0 and spinner_active:
                        live.stop()
                        spinner_active = False

                    last_position = new_position

            # Check if job reached terminal state
            if lifecycle_state in TERMINAL_STATES or result_state in TERMINAL_RESULT_STATES:
                # Stop spinner if still active
                if spinner_active:
                    live.stop()
                    spinner_active = False

                # Print any remaining logs
                if mlflow_run_id and full_log_file_path:
                    print_new_logs(
                        run_id=mlflow_run_id,
                        artifact_path=full_log_file_path,
                        dst_path=tmpdir,
                        last_position=0,  # Read from beginning to ensure we got everything
                    )

                success = result_state == "SUCCESS"
                log.info(f"Job status: {result_state}")

                return success

            # Wait before next poll
            time.sleep(RETRY_CHECK_INTERVAL_SECONDS)

    except KeyboardInterrupt:
        if spinner_active:
            live.stop()
        log.warning("Monitoring interrupted by user")
        log.info("Job is still running. Use 'sgcli status %s' to check status", run_id)
        return False

    finally:
        if spinner_active:
            live.stop()
        if tmpdir is not None:
            shutil.rmtree(tmpdir, ignore_errors=True)
