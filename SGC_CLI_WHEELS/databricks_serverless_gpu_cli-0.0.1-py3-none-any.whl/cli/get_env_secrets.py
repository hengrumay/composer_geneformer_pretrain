"""Fetch secrets from Databricks Secrets and export as environment variables."""

# TODO: integrate this with secret fetching for git repos
import argparse
import os
import sys

from databricks.sdk import WorkspaceClient


def main():
    """Fetch secrets and write them to a bash-sourceable file."""
    parser = argparse.ArgumentParser(description="Fetch Databricks secrets and export as environment variables")
    parser.add_argument(
        "--secret",
        action="append",
        nargs=3,
        metavar=("ENV_VAR", "SCOPE", "KEY"),
        required=True,
        help="Secret to fetch: ENV_VAR_NAME scope key",
    )
    parser.add_argument(
        "--output",
        default=os.path.expanduser("~/secrets_env.sh"),
        help="Output file for bash environment variables (default: ~/secrets_env.sh)",
    )

    args = parser.parse_args()

    w = WorkspaceClient()

    # Remove existing output file if it exists
    if os.path.exists(args.output):
        os.remove(args.output)

    for env_var_name, scope, key in args.secret:
        try:
            secret_value = w.dbutils.secrets.get(scope=scope, key=key)
            # Write to a temporary file that bash will source
            with open(args.output, "a", encoding="utf-8") as f:
                # Escape single quotes in the secret value for bash
                escaped_value = secret_value.replace("'", "'\\''")
                f.write(f"export {env_var_name}='{escaped_value}'\n")
            print(f"Successfully fetched secret for {env_var_name}")
        except Exception as e:
            print(f"ERROR: Failed to fetch secret for {env_var_name} from {scope}/{key}: {e}")
            sys.exit(1)


if __name__ == "__main__":
    main()
